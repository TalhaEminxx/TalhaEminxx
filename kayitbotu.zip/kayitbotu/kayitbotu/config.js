module.exports = {
    token: "tokenin", 
    prefix: "prefixin"
}

